Plugins Examples
================
The goal of this directory is to provide the basic understanding of the different plugins used with Backbone applications to make developers life easy.
There are large number of plugins but following are the choosen few plugins list which I found to be very useful.


NOTE: Before using these plugins into your projects; please have a look into following details
<ul>
	<li>Limitations</li>
	<li>Features support</li>
	<li>Issues raised in their respected git issue tracker</li>
</ul>

Plugins List
============
<ul> 
  <li>
    <strong>Models</strong>
    <ul>
      	<li>Backbone Deep Model</li>
 	<li>Backbone Forms</li>
    </ul>
  </li>
</ul>
