Models Plugins
==============
The goal of this directory is to provide the basic understanding of the Backbone's model based plugins used with Backbone applications.

List of Backbone's Model Plugins
=================================
<ol>
  <li>
    Backbone Deep Model:<br>
    Plugin Issues: <a href="https://github.com/powmedia/backbone-deep-model/issues" target="_blank">https://github.com/powmedia/backbone-deep-model/issues</a>
  </li>
  <li>
    Backbone Forms:<br>
    Plugin Issues: <a href="https://github.com/powmedia/backbone-forms/issues" target="_blank">https://github.com/powmedia/backbone-forms/issues</a>
  </li>
</ol>
