# Ch2 - Understanding Backbone Model

## Example 1:
* Create Backbone Model
* Create instance of Backbone Model
* Setting & getting default attributes
* Initialize a constructor
* Setting & getting attributes
* Get the list of all attributes

## Example 2:
* Unset attribute
* Cleaning all attributes
* Check if attributes is set or not
* Getting & Setting Model id

## Example 3:
* Access JSON data through URL method
* Parse data
* REST operations on JSON data

## Example 4:
* Attributes validation

## Example 5:
* Access 3rd parth service data through URL method
* Setting attributes to URL;
* Access attributes from within model