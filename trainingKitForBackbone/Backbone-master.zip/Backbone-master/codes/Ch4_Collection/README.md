# Ch3 - Understanding Backbone Collection

## Example 1:
* Create a Collection
* Passing Model to Collection
* Setting build-in Collection events
* Add/Remove Model from collection at the end
* Add/Remove Model from collection at the start
* Get the length of collection

## Example 2:
* Using pluck
* Using where

## Example 3:
* Sorting data & respected events