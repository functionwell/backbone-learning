# Ch5 - Understanding Backbone Router

## Example 1:
* Create a Router
* Backbone history
* Routes hash
* Simple route
* Route parameters
* Getting current route